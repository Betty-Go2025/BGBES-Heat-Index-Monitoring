# 🏫 DepEd Heat Index Monitoring & Advisory System

An institutional web-based Heat Index Monitoring and Decision Support System customized for Philippine schools, fully compliant with **DepEd Order No. 037, s. 2022** and **DOST-PAGASA Heat Index Guidelines**.

---

## 🚀 How to Open Through Link

### Option 1: Open Locally via Node.js Server
1. Double-click `start.bat` **or** open PowerShell in this folder and run:
   ```bash
   node server.js
   ```
2. Open your browser and navigate to:
   - **Local Link:** [http://localhost:5000](http://localhost:5000)
   - **Mobile / Local Network Link:** `http://<your-ip>:5000` *(displayed in terminal when started — access from any phone or laptop connected to the same Wi-Fi)*.

### Option 2: Open Directly Without Any Server
- Simply double-click `index.html` in your file explorer to open it directly in Google Chrome, Microsoft Edge, or Mozilla Firefox.

### Option 3: Deploy Free to Cloud (Shareable Public Web Link)
Because this application is self-contained (HTML5, Tailwind, Chart.js, Open-Meteo API), you can host it online for free in 30 seconds:
- **GitHub Pages:** Push this repository to GitHub and enable GitHub Pages under Settings -> Pages.
- **Vercel / Netlify:** Drag-and-drop the `Heat Index` folder directly to [Netlify Drop](https://app.netlify.com/drop) or deploy via Vercel for an instant `https://your-school-heat-index.vercel.app` link.

---

## 📋 DOST-PAGASA & DepEd Heat Index Threshold Matrix

| Heat Index Range | Classification (Tagalog) | Color Code | DepEd Institutional Mandate (DO 037, s. 2022) |
| :--- | :--- | :--- | :--- |
| **< 27°C** | Normal / Ligtas | 🟢 Green | Regular in-person classes and outdoor activities. |
| **27°C – 32°C** | Caution / Pag-iingat | 🟡 Yellow | Regular in-person classes. Hourly hydration breaks. Light PE clothing permitted. |
| **33°C – 41°C** | Extreme Caution / Labis na Pag-iingat | 🟠 Orange | Prohibit outdoor PE & assemblies between 10 AM - 3 PM. Mandatory 30-min water breaks. Relaxed uniform attire. |
| **42°C – 51°C** | **Danger / Panganib** | 🔴 Red | **AUTOMATIC SHIFT TO ALTERNATIVE DELIVERY MODES (ADM)**. In-person classes suspended. Shift to Modular / Online Learning. |
| **≥ 52°C** | **Extreme Danger / Labis na Panganib** | 🟣 Maroon | **TOTAL CANCELLATION** of all school activities & operations. Emergency DRRM protocols. |

---

## ✨ Key Features

1. **Live DOST-PAGASA / Open-Meteo Weather Integration**:
   - Live temperature, relative humidity, and heat index for 16+ key Philippine meteorological stations (Manila, QC, Dagupan, Tuguegarao, Cebu, Davao, etc.).
   - Includes **GPS Auto-Detect** to monitor conditions at your school's exact coordinates.

2. **Accurate Rothfusz Multi-Regression Heat Index Formula**:
   - Uses the official NOAA/PAGASA formula with relative humidity adjustment factors.

3. **24-Hour Heat Index Progression & Forecast Chart**:
   - Visual trend line showing projected hourly temperatures and warning peaks to enable early dismissal or proactive ADM declaration.

4. **Campus Classroom / Zone Heat Logger**:
   - Track microclimates in high-risk classrooms (e.g. 3rd-floor classrooms under galvanized iron tin roofs).
   - Data persists across sessions via browser LocalStorage.

5. **Official DepEd Notice & Memorandum Generator**:
   - Generate ready-to-print official school advisories with DepEd seal, Republic of the Philippines header, school name, and signature blocks.
   - **One-Click Copy:** Copies pre-formatted announcements ready for Facebook Pages, Messenger parent groups, and SMS broadcasts.

6. **Audio Sirens & Warning Alerts**:
   - Synthesizes alert chimes when Danger tier (≥42°C) is reached.

7. **Emergency First-Aid Guide**:
   - Side-by-side differentiation of Heat Cramps vs. Heat Exhaustion vs. Heat Stroke.
   - Quick-dial Philippine emergency hotlines (911, Red Cross 143, DepEd DRRMS).

---

## 🏛️ Customizing Your School Profile
Click the **"School Info"** button in the top navigation bar to configure:
- Official School Name
- DepEd School ID
- Division Office & Region
- School Principal / Head Name

All configurations save directly into your browser's persistent storage.
