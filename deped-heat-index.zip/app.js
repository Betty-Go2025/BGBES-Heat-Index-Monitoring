/**
 * DepEd Heat Index Monitoring & Advisory System
 * Standardized in compliance with DepEd Order No. 037, s. 2022 and DOST-PAGASA Guidelines
 */

// Official DOST-PAGASA Synoptic Weather Observatories & Monitoring Stations
const PAGASA_SYNOPTIC_STATIONS = [
  // National Capital Region (NCR)
  { id: "pag-1", name: "Science Garden, Quezon City", island: "NCR", province: "Metro Manila", lat: 14.6433, lon: 121.0436 },
  { id: "pag-2", name: "NAIA, Pasay City", island: "NCR", province: "Metro Manila", lat: 14.5086, lon: 121.0194 },
  { id: "pag-3", name: "Port Area, Manila", island: "NCR", province: "Metro Manila", lat: 14.5888, lon: 120.9702 },
  
  // Northern & Central Luzon
  { id: "pag-4", name: "Dagupan City Synoptic", island: "Luzon", province: "Pangasinan", lat: 16.0433, lon: 120.3333 },
  { id: "pag-5", name: "Tuguegarao City Synoptic", island: "Luzon", province: "Cagayan", lat: 17.6132, lon: 121.7270 },
  { id: "pag-6", name: "Aparri Synoptic", island: "Luzon", province: "Cagayan", lat: 18.3564, lon: 121.6414 },
  { id: "pag-7", name: "Laoag City Synoptic", island: "Luzon", province: "Ilocos Norte", lat: 18.1960, lon: 120.5927 },
  { id: "pag-8", name: "MMSU, Batac", island: "Luzon", province: "Ilocos Norte", lat: 18.0558, lon: 120.5436 },
  { id: "pag-9", name: "Sinait Synoptic", island: "Luzon", province: "Ilocos Sur", lat: 17.8683, lon: 120.4578 },
  { id: "pag-10", name: "Baguio City Synoptic", island: "Luzon", province: "Benguet", lat: 16.4023, lon: 120.5960 },
  { id: "pag-11", name: "ISU Echague", island: "Luzon", province: "Isabela", lat: 16.7111, lon: 121.6586 },
  { id: "pag-12", name: "TAU Camiling", island: "Luzon", province: "Tarlac", lat: 15.6961, lon: 120.4128 },
  { id: "pag-13", name: "Clark Airport / Angeles", island: "Luzon", province: "Pampanga", lat: 15.1860, lon: 120.5597 },
  { id: "pag-14", name: "Cubi Pt., Subic Bay", island: "Luzon", province: "Zambales", lat: 14.7944, lon: 120.2714 },
  { id: "pag-15", name: "Iba Synoptic", island: "Luzon", province: "Zambales", lat: 15.3267, lon: 119.9800 },
  { id: "pag-16", name: "Casiguran Synoptic", island: "Luzon", province: "Aurora", lat: 16.2797, lon: 122.1242 },
  { id: "pag-17", name: "Baler (Radar) Synoptic", island: "Luzon", province: "Aurora", lat: 15.7594, lon: 121.5622 },

  // Southern Luzon & Bicol
  { id: "pag-18", name: "Sangley Point Synoptic", island: "Luzon", province: "Cavite", lat: 14.4981, lon: 120.9122 },
  { id: "pag-19", name: "Ambulong, Tanauan", island: "Luzon", province: "Batangas", lat: 14.0883, lon: 121.0561 },
  { id: "pag-20", name: "Infanta Synoptic", island: "Luzon", province: "Quezon", lat: 14.7431, lon: 121.6508 },
  { id: "pag-21", name: "Tayabas City Synoptic", island: "Luzon", province: "Quezon", lat: 14.0264, lon: 121.5931 },
  { id: "pag-22", name: "Calapan Synoptic", island: "Luzon", province: "Oriental Mindoro", lat: 13.4117, lon: 121.1803 },
  { id: "pag-23", name: "San Jose Synoptic", island: "Luzon", province: "Occidental Mindoro", lat: 12.3528, lon: 121.0667 },
  { id: "pag-24", name: "Puerto Princesa City", island: "Luzon", province: "Palawan", lat: 9.7392, lon: 118.7353 },
  { id: "pag-25", name: "Coron Synoptic", island: "Luzon", province: "Palawan", lat: 12.0000, lon: 120.2000 },
  { id: "pag-26", name: "Cuyo Synoptic", island: "Luzon", province: "Palawan", lat: 10.8500, lon: 121.0167 },
  { id: "pag-27", name: "Daet Synoptic", island: "Luzon", province: "Camarines Norte", lat: 14.1278, lon: 122.9817 },
  { id: "pag-28", name: "Legazpi City Synoptic", island: "Luzon", province: "Albay", lat: 13.1391, lon: 123.7438 },
  { id: "pag-29", name: "Virac Synoptic", island: "Luzon", province: "Catanduanes", lat: 13.5833, lon: 124.2333 },
  { id: "pag-30", name: "Masbate City Synoptic", island: "Luzon", province: "Masbate", lat: 12.3711, lon: 123.6297 },
  { id: "pag-31", name: "Juban / Sorsogon", island: "Luzon", province: "Sorsogon", lat: 12.8500, lon: 123.9833 },

  // Visayas
  { id: "pag-32", name: "Roxas City Synoptic", island: "Visayas", province: "Capiz", lat: 11.5853, lon: 122.7511 },
  { id: "pag-33", name: "Iloilo City Synoptic", island: "Visayas", province: "Iloilo", lat: 10.7202, lon: 122.5621 },
  { id: "pag-34", name: "Mactan Int'l Airport", island: "Visayas", province: "Cebu", lat: 10.3157, lon: 123.8854 },
  { id: "pag-35", name: "Dumaguete City Synoptic", island: "Visayas", province: "Negros Oriental", lat: 9.3069, lon: 123.3056 },
  { id: "pag-36", name: "Tagbilaran City Synoptic", island: "Visayas", province: "Bohol", lat: 9.6500, lon: 123.8500 },
  { id: "pag-37", name: "Tacloban City Synoptic", island: "Visayas", province: "Leyte", lat: 11.2444, lon: 125.0039 },
  { id: "pag-38", name: "Catbalogan Synoptic", island: "Visayas", province: "Samar", lat: 11.7750, lon: 124.8817 },
  { id: "pag-39", name: "Catarman Synoptic", island: "Visayas", province: "Northern Samar", lat: 12.5000, lon: 124.6333 },
  { id: "pag-40", name: "Guiuan Synoptic", island: "Visayas", province: "Eastern Samar", lat: 11.0333, lon: 125.7333 },

  // Mindanao
  { id: "pag-41", name: "Zamboanga City Synoptic", island: "Mindanao", province: "Zamboanga del Sur", lat: 6.9214, lon: 122.0790 },
  { id: "pag-42", name: "Dipolog Synoptic", island: "Mindanao", province: "Zamboanga del Norte", lat: 8.5833, lon: 123.3333 },
  { id: "pag-43", name: "Cagayan de Oro / El Salvador", island: "Mindanao", province: "Misamis Oriental", lat: 8.4542, lon: 124.6319 },
  { id: "pag-44", name: "Malaybalay Synoptic", island: "Mindanao", province: "Bukidnon", lat: 8.1575, lon: 125.1278 },
  { id: "pag-45", name: "Davao City Airport", island: "Mindanao", province: "Davao del Sur", lat: 7.1253, lon: 125.6456 },
  { id: "pag-46", name: "General Santos City", island: "Mindanao", province: "South Cotabato", lat: 6.1164, lon: 125.1716 },
  { id: "pag-47", name: "Butuan City Synoptic", island: "Mindanao", province: "Agusan del Norte", lat: 8.9492, lon: 125.5436 },
  { id: "pag-48", name: "Surigao City Synoptic", island: "Mindanao", province: "Surigao del Norte", lat: 9.7833, lon: 125.4833 },
  { id: "pag-49", name: "Hinatuan Synoptic", island: "Mindanao", province: "Surigao del Sur", lat: 8.3667, lon: 126.3333 },
  { id: "pag-50", name: "Cotabato City Synoptic", island: "Mindanao", province: "Maguindanao", lat: 7.2236, lon: 124.2464 }
];

// Key Quick Selector Stations (for dropdown)
const PH_LOCATIONS = PAGASA_SYNOPTIC_STATIONS.map(s => ({
  name: `${s.name} (${s.province})`,
  lat: s.lat,
  lon: s.lon,
  id: s.id
}));

// App State
let appState = {
  selectedLocation: PH_LOCATIONS[0],
  airTemp: 34.0,
  humidity: 65,
  heatIndex: 42.5,
  soundAlertEnabled: true,
  audioContext: null,
  hourlyData: [],
  chartInstance: null,
  schoolProfile: {
    schoolName: "Ramon Magsaysay High School",
    schoolId: "301234",
    region: "National Capital Region (NCR)",
    division: "Schools Division Office of Manila",
    principalName: "Dr. Maria Santos, Ed.D."
  },
  classrooms: [
    {
      id: "rm-1",
      name: "Room 302 - Grade 10 Rizal",
      building: "Bldg B, 3rd Floor (Under GI Sheet Roof)",
      temp: 36.5,
      humidity: 68,
      heatIndex: 49.2,
      notes: "Tin roof causes intense heat retention. 2 ceiling fans operating.",
      timestamp: "10:30 AM"
    },
    {
      id: "rm-2",
      name: "Room 101 - Grade 7 Bonifacio",
      building: "Bldg A, Ground Floor",
      temp: 32.0,
      humidity: 62,
      heatIndex: 38.4,
      notes: "Good shade from acacia trees. Well-ventilated cross breeze.",
      timestamp: "10:15 AM"
    },
    {
      id: "rm-3",
      name: "Covered Court / Gymnasium",
      building: "Campus Sports Center",
      temp: 35.0,
      humidity: 65,
      heatIndex: 43.8,
      notes: "Extreme radiant heat from high metallic canopy.",
      timestamp: "10:00 AM"
    }
  ]
};

// Rothfusz Heat Index Formula (Official PAGASA & NOAA multi-regression)
function calculateHeatIndex(T_celsius, R) {
  // Convert T to Fahrenheit
  let T = (T_celsius * 9 / 5) + 32;
  
  // Preliminary simple equation
  let HI = 0.5 * (T + 61.0 + ((T - 68.0) * 1.2) + (R * 0.094));

  if (HI >= 80.0) {
    // Full Rothfusz regression
    HI = -42.379 + (2.04901523 * T) + (10.14333127 * R)
         - (0.22475541 * T * R) - (0.00683783 * T * T)
         - (0.05481717 * R * R) + (0.00122874 * T * T * R)
         + (0.00085282 * T * R * R) - (0.00000199 * T * T * R * R);

    // Adjustments
    if (R < 13 && T >= 80 && T <= 112) {
      let adj = ((13 - R) / 4) * Math.sqrt((17 - Math.abs(T - 95.0)) / 17);
      HI -= adj;
    } else if (R > 85 && T >= 80 && T <= 87) {
      let adj = ((R - 85) / 10) * ((87 - T) / 5);
      HI += adj;
    }
  }

  // Convert back to Celsius
  let HI_celsius = (HI - 32) * 5 / 9;
  return Math.round(HI_celsius * 10) / 10;
}

// DepEd / PAGASA Classification Matrix
function getHeatLevelDetails(hi) {
  if (hi < 27.0) {
    return {
      tier: "SAFE",
      tagalog: "Ligtas / Normal",
      color: "#10b981",
      badgeClass: "bg-emerald-100 text-emerald-800 border-emerald-300",
      classStatus: "REGULAR IN-PERSON CLASSES",
      classIcon: "✅",
      classStatusColor: "text-emerald-800 bg-emerald-50 border-emerald-300",
      classDesc: "Environmental conditions are safe. Regular classroom instruction and activities may proceed as normal.",
      outdoor: "NORMAL OUTDOOR ACTIVITIES ALLOWED",
      outdoorDesc: "Physical education, flag ceremonies, and outdoor games may proceed with routine water breaks.",
      ventilation: "Standard Room Ventilation",
      ventilationDesc: "Keep windows and doors open for natural airflow.",
      uniform: "Standard DepEd Uniform",
      uniformDesc: "Learners may wear standard school uniforms.",
      hydration: "Routine Hydration",
      hydrationDesc: "Encourage water drinking during regular recess breaks.",
      isDanger: false,
      isExtreme: false
    };
  } else if (hi >= 27.0 && hi < 33.0) {
    return {
      tier: "CAUTION",
      tagalog: "Pag-iingat",
      color: "#f59e0b",
      badgeClass: "bg-amber-100 text-amber-800 border-amber-300",
      classStatus: "REGULAR CLASSES WITH PRECAUTION",
      classIcon: "⚠️",
      classStatusColor: "text-amber-900 bg-amber-50 border-amber-300",
      classDesc: "Fatigue is possible with prolonged exposure and activity. In-person classes proceed with increased hydration reminders and monitor learners with asthma or allergies.",
      outdoor: "MODERATE OUTDOOR ACTIVITY",
      outdoorDesc: "Limit direct sun exposure; hold sports under shaded covered courts if possible.",
      ventilation: "Active Air Circulation",
      ventilationDesc: "Ensure all classroom fans are running and windows open.",
      uniform: "Optional Relaxed Attire",
      uniformDesc: "Learners may wear school PE shirt or light white shirt if uncomfortable.",
      hydration: "Hourly Water Breaks",
      hydrationDesc: "Announce regular water drinking intervals every 45-60 minutes.",
      isDanger: false,
      isExtreme: false
    };
  } else if (hi >= 33.0 && hi < 42.0) {
    return {
      tier: "EXTREME CAUTION",
      tagalog: "Labis na Pag-iingat",
      color: "#f97316",
      badgeClass: "bg-orange-100 text-orange-800 border-orange-300",
      classStatus: "HIGH ALERT • PRECAUTIONARY IN-PERSON",
      classIcon: "🔥",
      classStatusColor: "text-orange-950 bg-orange-50 border-orange-300",
      classDesc: "Heat cramps and heat exhaustion are possible. School heads must closely monitor midday temperatures and prepare contingency modules should index rise above 41°C.",
      outdoor: "OUTDOOR ACTIVITIES RESTRICTED (10 AM - 3 PM)",
      outdoorDesc: "DepEd Guideline: Strenuous outdoor PE drills, noon flag retreat, and sun-exposed assemblies are suspended between 10:00 AM and 3:00 PM.",
      ventilation: "Maximum Classroom Cooling",
      ventilationDesc: "Clean fan blades, pull down light shades/curtains against direct sun, rotate seating if side walls are hot.",
      uniform: "Comfortable Attire Policy Mandated",
      uniformDesc: "Students and teachers are explicitly encouraged to wear light-colored, breathable clothing or PE uniforms.",
      hydration: "Mandatory 30-Minute Water Breaks",
      hydrationDesc: "Teachers must halt lecture every 30 minutes for mandatory water intake.",
      isDanger: false,
      isExtreme: false
    };
  } else if (hi >= 42.0 && hi < 52.0) {
    return {
      tier: "DANGER",
      tagalog: "Panganib",
      color: "#ef4444",
      badgeClass: "bg-red-100 text-red-800 border-red-300",
      classStatus: "AUTOMATIC SHIFT TO ALTERNATIVE DELIVERY MODES (ADM)",
      classIcon: "🚫",
      classStatusColor: "text-red-950 bg-red-50 border-red-400",
      classDesc: "DepEd Order No. 037, s. 2022 Mandate: Heat cramps and exhaustion likely; heat stroke probable. School heads are officially authorized and directed to suspend in-person classes and implement Modular Distance Learning or Online Asynchronous Modality.",
      outdoor: "OUTDOOR ACTIVITIES STRICTLY PROHIBITED",
      outdoorDesc: "Immediate cancellation of all outdoor student activities, rehearsals, and athletics.",
      ventilation: "Classroom Evacuation / Relocation",
      ventilationDesc: "Learners still on campus awaiting dismissal must be moved to ground-floor, well-ventilated, or air-conditioned rooms.",
      uniform: "Full Uniform Waiver",
      uniformDesc: "Strict uniform rules waived; light, comfortable, breathable attire permitted.",
      hydration: "Continuous Hydration & Clinic Standby",
      hydrationDesc: "School clinic on active standby with cold compresses, oral rehydration salts (ORS), and ice packs.",
      isDanger: true,
      isExtreme: false
    };
  } else {
    return {
      tier: "EXTREME DANGER",
      tagalog: "Labis na Panganib",
      color: "#881337",
      badgeClass: "bg-rose-950 text-rose-100 border-rose-800",
      classStatus: "MANDATORY TOTAL SUSPENSION OF SCHOOL OPERATIONS",
      classIcon: "🛑",
      classStatusColor: "text-white bg-rose-900 border-rose-950",
      classDesc: "CRITICAL LIFE SAFETY EMERGENCY: Heat index is 52°C or higher. Heat stroke is imminent. In-person classes and non-essential school work are completely cancelled. Emergency coordination with Local DRRM Office.",
      outdoor: "ALL ACTIVITIES SUSPENDED",
      outdoorDesc: "Strict prohibition of all campus operations and outdoor movement.",
      ventilation: "Seek Immediate Cool Shelter",
      ventilationDesc: "Stay in cool rooms; avoid exposure to metallic roof radiant heat.",
      uniform: "Not Applicable",
      uniformDesc: "Classes and school gatherings are suspended.",
      hydration: "Critical Health Precautions",
      hydrationDesc: "Emergency protocols active. Immediate medical intervention for any symptomatic individual.",
      isDanger: true,
      isExtreme: true
    };
  }
}

// Audio Synthesizer for High Heat Alert (Zero external dependencies)
function playDangerAlertSound() {
  if (!appState.soundAlertEnabled) return;
  try {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) return;
    
    if (!appState.audioContext) {
      appState.audioContext = new AudioContext();
    }
    
    const ctx = appState.audioContext;
    if (ctx.state === 'suspended') {
      ctx.resume();
    }

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = "sawtooth";
    osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
    osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.2); // A5
    osc.frequency.exponentialRampToValueAtTime(587.33, ctx.currentTime + 0.4);

    gain.gain.setValueAtTime(0.2, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.45);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + 0.5);
  } catch (e) {
    console.warn("Audio Alert blocked or not permitted yet:", e);
  }
}

function toggleAudioAlert() {
  appState.soundAlertEnabled = !appState.soundAlertEnabled;
  const btn = document.getElementById("soundToggleBtn");
  const icon = document.getElementById("soundIcon");
  const text = document.getElementById("soundStatusText");

  if (appState.soundAlertEnabled) {
    icon.textContent = "🔔";
    text.textContent = "Alert Audio: On";
    btn.className = "flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-blue-900/60 hover:bg-blue-800 text-blue-100 transition border border-blue-400/30";
    playDangerAlertSound();
  } else {
    icon.textContent = "🔕";
    text.textContent = "Alert Audio: Muted";
    btn.className = "flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-700/60 hover:bg-slate-600 text-slate-300 transition border border-slate-500/30";
  }
}

// Update Gauge Needle
function updateGaugeNeedle(hi) {
  const needle = document.getElementById("gaugeNeedle");
  if (!needle) return;

  // Scale map: 20°C -> -90 deg (left), 33°C -> 0 deg (top), 55°C -> +90 deg (right)
  // Let range be 20°C to 55°C (35 span) => -90 to +90 deg (180 deg span)
  let clamped = Math.max(20, Math.min(55, hi));
  let angle = ((clamped - 20) / (55 - 20)) * 180 - 90;
  
  needle.style.transform = `rotate(${angle}deg)`;
}

// Render Dashboard Directives & UI
function renderDashboard() {
  const hi = appState.heatIndex;
  const details = getHeatLevelDetails(hi);

  // Update numerical badges
  document.getElementById("currentHeatIndexVal").textContent = hi.toFixed(1);
  document.getElementById("currentAirTemp").textContent = appState.airTemp.toFixed(1);
  document.getElementById("currentHumidity").textContent = Math.round(appState.humidity);
  document.getElementById("readingTimestamp").textContent = "Updated " + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  // Update Heat Badge
  const badge = document.getElementById("currentHeatLevelBadge");
  badge.textContent = `${details.tier} (${details.tagalog.toUpperCase()})`;
  badge.className = `inline-block px-4 py-1 rounded-full text-xs sm:text-sm font-extrabold uppercase tracking-wide border ${details.badgeClass}`;

  // Update Needle
  updateGaugeNeedle(hi);

  // Update Urgent Alert Banner
  const alertBanner = document.getElementById("urgentAlertBanner");
  const alertText = document.getElementById("urgentAlertText");
  if (details.isDanger) {
    alertBanner.classList.remove("hidden");
    if (details.isExtreme) {
      alertText.textContent = `CRITICAL ALERT: Heat Index is ${hi.toFixed(1)}°C (Extreme Danger). Immediate total suspension of all in-person classes and campus operations.`;
    } else {
      alertText.textContent = `DEPED ACTION TRIGGERED: Heat Index is ${hi.toFixed(1)}°C (Danger Tier). School heads authorized under DO 037, s. 2022 to shift to Alternative Delivery Modes (ADM).`;
    }
    playDangerAlertSound();
  } else {
    alertBanner.classList.add("hidden");
  }

  // Update DepEd Decision Engine Cards
  const classCard = document.getElementById("protocolClassStatusCard");
  classCard.className = `mt-4 p-4 rounded-xl border-2 transition-all duration-300 ${details.classStatusColor}`;
  document.getElementById("protocolClassStatusTitle").textContent = details.classStatus;
  document.getElementById("protocolClassStatusIcon").textContent = details.classIcon;
  document.getElementById("protocolClassStatusDesc").textContent = details.classDesc;

  document.getElementById("directiveOutdoorStatus").textContent = details.outdoor;
  document.getElementById("directiveOutdoorDesc").textContent = details.outdoorDesc;

  document.getElementById("directiveVentilationStatus").textContent = details.ventilation;
  document.getElementById("directiveVentilationDesc").textContent = details.ventilationDesc;

  document.getElementById("directiveUniformStatus").textContent = details.uniform;
  document.getElementById("directiveUniformDesc").textContent = details.uniformDesc;

  document.getElementById("directiveHydrationStatus").textContent = details.hydration;
  document.getElementById("directiveHydrationDesc").textContent = details.hydrationDesc;

  // Sync to official memo preview as well
  generateAdvisoryDocument();
}

// Fetch Real-Time Philippine Weather via Open-Meteo API
async function fetchWeatherData(lat, lon, locationName) {
  try {
    document.getElementById("readingTimestamp").textContent = "Fetching live weather...";
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m&hourly=temperature_2m,relative_humidity_2m&timezone=Asia%2FManila`;
    
    const resp = await fetch(url);
    if (!resp.ok) throw new Error("Weather API request failed");
    const data = await resp.json();

    if (data.current) {
      appState.airTemp = data.current.temperature_2m;
      appState.humidity = data.current.relative_humidity_2m;
      appState.heatIndex = calculateHeatIndex(appState.airTemp, appState.humidity);

      // Process hourly data for next 24 hours
      if (data.hourly && data.hourly.time) {
        const hourlyArr = [];
        const times = data.hourly.time;
        const temps = data.hourly.temperature_2m;
        const hums = data.hourly.relative_humidity_2m;
        
        // Find current hour index
        const nowIso = new Date().toISOString().slice(0, 13);
        let startIdx = times.findIndex(t => t.startsWith(nowIso));
        if (startIdx === -1) startIdx = 0;

        for (let i = startIdx; i < Math.min(startIdx + 24, times.length); i++) {
          const tVal = temps[i];
          const hVal = hums[i];
          const hiVal = calculateHeatIndex(tVal, hVal);
          const hourLabel = new Date(times[i]).toLocaleTimeString([], { hour: 'numeric', hour12: true });
          hourlyArr.push({
            time: hourLabel,
            temp: tVal,
            humidity: hVal,
            heatIndex: hiVal
          });
        }
        appState.hourlyData = hourlyArr;
        renderHourlyChart();
      }

      renderDashboard();
    }
  } catch (err) {
    console.warn("Live weather fetch failed, using realistic fallback:", err);
    // Graceful offline fallback with realistic Philippine climate profile
    simulateDefaultWeather();
    renderDashboard();
  }
}

function simulateDefaultWeather() {
  const currentHour = new Date().getHours();
  // Typical noon heat peak
  let baseTemp = 32.0;
  if (currentHour >= 11 && currentHour <= 15) {
    baseTemp = 35.5;
  } else if (currentHour >= 8 && currentHour < 11) {
    baseTemp = 33.0;
  }
  appState.airTemp = baseTemp;
  appState.humidity = 64;
  appState.heatIndex = calculateHeatIndex(appState.airTemp, appState.humidity);

  // Generate simulated hourly progression
  const simHourly = [];
  for (let h = 6; h <= 20; h++) {
    let t = 28 + Math.sin((h - 6) / 14 * Math.PI) * 8.5;
    let hum = 75 - Math.sin((h - 6) / 14 * Math.PI) * 15;
    let hi = calculateHeatIndex(t, hum);
    let label = (h % 12 === 0 ? 12 : h % 12) + (h >= 12 ? " PM" : " AM");
    simHourly.push({
      time: label,
      temp: Math.round(t * 10) / 10,
      humidity: Math.round(hum),
      heatIndex: hi
    });
  }
  appState.hourlyData = simHourly;
  renderHourlyChart();
}

function onCitySelected(cityName) {
  const loc = PH_LOCATIONS.find(l => l.name === cityName);
  if (loc) {
    appState.selectedLocation = loc;
    fetchWeatherData(loc.lat, loc.lon, loc.name);
  }
}

function fetchCurrentGpsWeather() {
  if (!navigator.geolocation) {
    alert("Geolocation is not supported by your browser.");
    return;
  }
  document.getElementById("readingTimestamp").textContent = "Locating GPS coordinates...";
  navigator.geolocation.getCurrentPosition(
    pos => {
      const lat = pos.coords.latitude;
      const lon = pos.coords.longitude;
      appState.selectedLocation = { name: "Current GPS Location", lat, lon };
      
      // Add or update GPS option in select dropdown
      const select = document.getElementById("quickCitySelect");
      let opt = Array.from(select.options).find(o => o.value === "Current GPS Location");
      if (!opt) {
        opt = document.createElement("option");
        opt.value = "Current GPS Location";
        opt.textContent = "📍 My GPS Location";
        select.prepend(opt);
      }
      select.value = "Current GPS Location";

      fetchWeatherData(lat, lon, "My Location");
    },
    err => {
      alert("Unable to retrieve location: " + err.message + ". Please select a city from the list.");
      document.getElementById("readingTimestamp").textContent = "GPS access denied.";
    }
  );
}

function refreshWeatherData() {
  if (appState.selectedLocation) {
    fetchWeatherData(appState.selectedLocation.lat, appState.selectedLocation.lon, appState.selectedLocation.name);
  }
}

// 24-Hour Trend Chart via Chart.js
function renderHourlyChart() {
  const ctx = document.getElementById("hourlyTrendChart");
  if (!ctx) return;

  const labels = appState.hourlyData.map(d => d.time);
  const hiData = appState.hourlyData.map(d => d.heatIndex);
  const tempData = appState.hourlyData.map(d => d.temp);

  if (appState.chartInstance) {
    appState.chartInstance.destroy();
  }

  appState.chartInstance = new Chart(ctx, {
    type: 'line',
    data: {
      labels: labels,
      datasets: [
        {
          label: 'Heat Index (°C)',
          data: hiData,
          borderColor: '#ef4444',
          backgroundColor: 'rgba(239, 68, 68, 0.1)',
          fill: true,
          tension: 0.35,
          borderWidth: 3,
          pointBackgroundColor: hiData.map(v => v >= 42 ? '#881337' : '#ef4444'),
          pointRadius: 4,
          pointHoverRadius: 6
        },
        {
          label: 'Air Temperature (°C)',
          data: tempData,
          borderColor: '#3b82f6',
          borderDash: [4, 4],
          borderWidth: 2,
          fill: false,
          tension: 0.35,
          pointRadius: 2
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'top',
          labels: {
            font: { family: 'Plus Jakarta Sans', size: 11, weight: 'bold' }
          }
        },
        tooltip: {
          backgroundColor: '#0f172a',
          titleFont: { size: 12, weight: 'bold' },
          bodyFont: { size: 12 },
          callbacks: {
            afterBody: function(items) {
              const val = items[0].raw;
              const detail = getHeatLevelDetails(val);
              return `DepEd Tier: ${detail.tier}\nAction: ${detail.classStatus}`;
            }
          }
        }
      },
      scales: {
        y: {
          min: 24,
          max: 54,
          ticks: {
            stepSize: 5,
            callback: value => value + '°C'
          },
          grid: {
            color: context => {
              if (context.tick.value === 42) return 'rgba(239, 68, 68, 0.6)'; // Red Danger threshold line
              return 'rgba(226, 232, 240, 0.6)';
            },
            lineWidth: context => context.tick.value === 42 ? 2 : 1
          }
        },
        x: {
          grid: { display: false }
        }
      }
    }
  });
}

// TAB 2: Calculator Tab Logic
function onManualCalculatorChange() {
  const t = parseFloat(document.getElementById("inputTemp").value);
  const h = parseFloat(document.getElementById("inputHumidity").value);

  document.getElementById("dispTempSlider").textContent = t.toFixed(1) + " °C";
  document.getElementById("dispHumiditySlider").textContent = h + " %";

  document.getElementById("numInputTemp").value = t.toFixed(1);
  document.getElementById("numInputHumidity").value = h;

  updateManualCalculation(t, h);
}

function syncManualInputs(source) {
  let t = parseFloat(document.getElementById("numInputTemp").value) || 30;
  let h = parseFloat(document.getElementById("numInputHumidity").value) || 50;

  t = Math.max(15, Math.min(55, t));
  h = Math.max(5, Math.min(100, h));

  document.getElementById("inputTemp").value = t;
  document.getElementById("inputHumidity").value = h;

  document.getElementById("dispTempSlider").textContent = t.toFixed(1) + " °C";
  document.getElementById("dispHumiditySlider").textContent = h + " %";

  updateManualCalculation(t, h);
}

function setScenario(temp, hum) {
  document.getElementById("inputTemp").value = temp;
  document.getElementById("inputHumidity").value = hum;
  onManualCalculatorChange();
}

function updateManualCalculation(t, h) {
  const hi = calculateHeatIndex(t, h);
  const details = getHeatLevelDetails(hi);

  document.getElementById("calcResultVal").textContent = hi.toFixed(1);
  const badge = document.getElementById("calcResultBadge");
  badge.textContent = `${details.tier} (${details.tagalog.toUpperCase()})`;
  badge.className = `inline-block px-3.5 py-1 rounded-full text-xs font-extrabold uppercase tracking-wide border ${details.badgeClass}`;

  // Physiological effects
  let physio = "";
  if (hi < 27) {
    physio = "No significant heat stress. Regular metabolic thermal equilibrium.";
  } else if (hi < 33) {
    physio = "Fatigue is possible with prolonged physical exertion. Early signs of mild dehydration.";
  } else if (hi < 42) {
    physio = "Heat cramps and heat exhaustion possible. Continuing vigorous physical activity can precipitate heat stroke.";
  } else if (hi < 52) {
    physio = "Heat cramps and exhaustion likely. Heat stroke is highly probable with continued physical strain.";
  } else {
    physio = "HEAT STROKE IS IMMINENT. Dangerous elevation of core body temperature. Severe medical crisis.";
  }
  document.getElementById("calcPhysioEffect").textContent = physio;
  document.getElementById("calcDepEdPolicy").textContent = details.classStatus + ": " + details.classDesc;
}

function applyCalculatedToLive() {
  const t = parseFloat(document.getElementById("inputTemp").value);
  const h = parseFloat(document.getElementById("inputHumidity").value);
  appState.airTemp = t;
  appState.humidity = h;
  appState.heatIndex = calculateHeatIndex(t, h);
  
  renderDashboard();
  switchTab("dashboard");
  
  // Show brief feedback toast
  alert(`Applied reading: Temp ${t}°C, Humidity ${h}% => Heat Index ${appState.heatIndex}°C to School Operations Dashboard.`);
}

// TAB 3: Classroom Heat Index Logger
function renderRoomsTable() {
  const tbody = document.getElementById("roomsTableBody");
  const noNotice = document.getElementById("noRoomsNotice");
  if (!tbody) return;

  tbody.innerHTML = "";

  if (appState.classrooms.length === 0) {
    noNotice.classList.remove("hidden");
  } else {
    noNotice.classList.add("hidden");
  }

  let safeCount = 0;
  let cautionCount = 0;
  let dangerCount = 0;

  appState.classrooms.forEach((rm, index) => {
    const details = getHeatLevelDetails(rm.heatIndex);
    if (rm.heatIndex < 33) safeCount++;
    else if (rm.heatIndex < 42) cautionCount++;
    else dangerCount++;

    const tr = document.createElement("tr");
    tr.className = "hover:bg-slate-50 transition border-b border-slate-100";
    tr.innerHTML = `
      <td class="py-3 px-4 font-bold text-slate-800">
        ${rm.name}
        <div class="text-[11px] font-normal text-slate-400">${rm.notes || 'No notes logged'}</div>
      </td>
      <td class="py-3 px-4 text-slate-600">${rm.building}</td>
      <td class="py-3 px-4 font-semibold">${rm.temp.toFixed(1)}°C</td>
      <td class="py-3 px-4 font-semibold">${rm.humidity}%</td>
      <td class="py-3 px-4">
        <span class="font-extrabold text-sm ${rm.heatIndex >= 42 ? 'text-red-600' : 'text-slate-800'}">${rm.heatIndex.toFixed(1)}°C</span>
      </td>
      <td class="py-3 px-4">
        <span class="inline-block px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${details.badgeClass}">
          ${details.tier}
        </span>
      </td>
      <td class="py-3 px-4 text-right">
        <button onclick="deleteRoomReading('${rm.id}')" class="text-red-500 hover:text-red-700 font-medium text-xs">
          Delete
        </button>
      </td>
    `;
    tbody.appendChild(tr);
  });

  document.getElementById("totalRoomsCount").textContent = appState.classrooms.length;
  document.getElementById("safeRoomsCount").textContent = safeCount;
  document.getElementById("cautionRoomsCount").textContent = cautionCount;
  document.getElementById("dangerRoomsCount").textContent = dangerCount;
}

function openAddRoomModal() {
  document.getElementById("addRoomModal").classList.remove("hidden");
}

function closeAddRoomModal() {
  document.getElementById("addRoomModal").classList.add("hidden");
}

function submitRoomReading(e) {
  e.preventDefault();
  const name = document.getElementById("modalRoomName").value.trim();
  const bldg = document.getElementById("modalBuildingFloor").value.trim();
  const t = parseFloat(document.getElementById("modalRoomTemp").value);
  const h = parseFloat(document.getElementById("modalRoomHumidity").value);
  const notes = document.getElementById("modalRoomNotes").value.trim();

  const hi = calculateHeatIndex(t, h);

  const newRoom = {
    id: "rm-" + Date.now(),
    name: name,
    building: bldg,
    temp: t,
    humidity: h,
    heatIndex: hi,
    notes: notes,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  };

  appState.classrooms.unshift(newRoom);
  saveToLocalStorage();
  renderRoomsTable();
  closeAddRoomModal();

  // Reset form
  document.getElementById("modalRoomName").value = "";
  document.getElementById("modalBuildingFloor").value = "";
  document.getElementById("modalRoomNotes").value = "";
}

function deleteRoomReading(id) {
  if (confirm("Delete this classroom heat reading?")) {
    appState.classrooms = appState.classrooms.filter(r => r.id !== id);
    saveToLocalStorage();
    renderRoomsTable();
  }
}

// TAB: DOST-PAGASA Synoptic Stations Bulletin Logic
async function fetchAllPagasaStations() {
  const tbody = document.getElementById("pagasaBulletinTableBody");
  if (tbody) {
    tbody.innerHTML = `
      <tr>
        <td colspan="8" class="text-center py-10 text-slate-500 font-medium">
          <div class="inline-block animate-spin mr-2">🔄</div> Fetching latest DOST-PAGASA station observations across the Philippines...
        </td>
      </tr>
    `;
  }

  try {
    // Open-Meteo supports querying multiple coordinates in one batch request
    const lats = PAGASA_SYNOPTIC_STATIONS.map(s => s.lat).join(",");
    const lons = PAGASA_SYNOPTIC_STATIONS.map(s => s.lon).join(",");
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lats}&longitude=${lons}&current=temperature_2m,relative_humidity_2m&timezone=Asia%2FManila`;

    const resp = await fetch(url);
    if (!resp.ok) throw new Error("PAGASA stations data batch fetch failed");
    const data = await resp.json();

    const stationsList = [];
    const results = Array.isArray(data) ? data : [data];

    PAGASA_SYNOPTIC_STATIONS.forEach((station, idx) => {
      const item = results[idx];
      let temp = 33.0;
      let humidity = 65;

      if (item && item.current) {
        temp = item.current.temperature_2m;
        humidity = item.current.relative_humidity_2m;
      } else {
        // Realistic regional baseline
        temp = station.name.includes("Baguio") ? 23.5 : (station.province === "Pangasinan" || station.province === "Cagayan" ? 36.0 : 33.5);
        humidity = 64;
      }

      const hi = calculateHeatIndex(temp, humidity);
      const details = getHeatLevelDetails(hi);

      stationsList.push({
        ...station,
        temp,
        humidity,
        heatIndex: hi,
        details
      });
    });

    // Sort by Heat Index Descending (highest risk first)
    stationsList.sort((a, b) => b.heatIndex - a.heatIndex);
    appState.pagasaStationsData = stationsList;

    renderPagasaTable(stationsList);
    updatePagasaSummaryMetrics(stationsList);

    const timeLabel = document.getElementById("pagasaLastRefreshed");
    if (timeLabel) {
      timeLabel.textContent = "Last updated: " + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }) + " (PST)";
    }
  } catch (err) {
    console.warn("Batch weather request failed, generating realistic PAGASA baseline:", err);
    generatePagasaFallbackData();
  }
}

function generatePagasaFallbackData() {
  const currentHour = new Date().getHours();
  const isPeak = currentHour >= 11 && currentHour <= 15;

  const stationsList = PAGASA_SYNOPTIC_STATIONS.map(station => {
    let baseT = 32.5;
    let baseH = 68;

    // Geographic thermal profiles
    if (station.name.includes("Baguio")) {
      baseT = 23.0;
      baseH = 75;
    } else if (station.province === "Pangasinan" || station.name.includes("Dagupan")) {
      baseT = isPeak ? 36.5 : 34.0;
      baseH = 66;
    } else if (station.province === "Cagayan" || station.name.includes("Tuguegarao")) {
      baseT = isPeak ? 36.8 : 34.2;
      baseH = 64;
    } else if (station.island === "NCR") {
      baseT = isPeak ? 35.0 : 33.0;
      baseH = 65;
    } else if (station.island === "Visayas") {
      baseT = isPeak ? 34.2 : 32.0;
      baseH = 70;
    } else if (station.island === "Mindanao") {
      baseT = isPeak ? 34.0 : 32.2;
      baseH = 68;
    }

    const hi = calculateHeatIndex(baseT, baseH);
    const details = getHeatLevelDetails(hi);

    return {
      ...station,
      temp: baseT,
      humidity: baseH,
      heatIndex: hi,
      details
    };
  });

  stationsList.sort((a, b) => b.heatIndex - a.heatIndex);
  appState.pagasaStationsData = stationsList;
  renderPagasaTable(stationsList);
  updatePagasaSummaryMetrics(stationsList);
}

function updatePagasaSummaryMetrics(stations) {
  if (!stations || stations.length === 0) return;

  const dangerCount = stations.filter(s => s.heatIndex >= 42).length;
  const highest = stations[0];
  const lowest = stations[stations.length - 1];

  document.getElementById("pagasaTotalStationsCount").textContent = stations.length;
  document.getElementById("pagasaDangerStationsCount").textContent = dangerCount;
  
  document.getElementById("pagasaHighestIndex").textContent = highest.heatIndex.toFixed(1) + "°C";
  document.getElementById("pagasaHighestLocation").textContent = `${highest.name} (${highest.province})`;

  document.getElementById("pagasaLowestIndex").textContent = lowest.heatIndex.toFixed(1) + "°C";
  document.getElementById("pagasaLowestLocation").textContent = `${lowest.name} (${lowest.province})`;
}

function renderPagasaTable(stations) {
  const tbody = document.getElementById("pagasaBulletinTableBody");
  if (!tbody) return;

  tbody.innerHTML = "";

  if (stations.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="8" class="text-center py-8 text-slate-400">
          No PAGASA stations match the current filter or search query.
        </td>
      </tr>
    `;
    return;
  }

  stations.forEach(st => {
    const isDanger = st.heatIndex >= 42;
    const isExtreme = st.heatIndex >= 52;
    const tr = document.createElement("tr");
    tr.className = `hover:bg-slate-50 transition border-b border-slate-100 ${isDanger ? 'bg-red-50/40' : ''}`;

    tr.innerHTML = `
      <td class="py-3 px-4 font-bold text-slate-800">
        <div class="flex items-center gap-1.5">
          ${isDanger ? '<span class="text-xs">⚠️</span>' : ''}
          <span>${st.name}</span>
        </div>
        <div class="text-[11px] font-normal text-slate-500">${st.province}</div>
      </td>
      <td class="py-3 px-4">
        <span class="inline-block px-2 py-0.5 rounded text-[10px] font-bold ${st.island === 'NCR' ? 'bg-blue-100 text-blue-800' : 'bg-slate-100 text-slate-700'}">
          ${st.island}
        </span>
      </td>
      <td class="py-3 px-4 font-semibold text-slate-700">${st.temp.toFixed(1)}°C</td>
      <td class="py-3 px-4 font-semibold text-slate-700">${Math.round(st.humidity)}%</td>
      <td class="py-3 px-4">
        <span class="font-black text-sm ${isDanger ? 'text-red-700 font-mono' : 'text-slate-800'}">
          ${st.heatIndex.toFixed(1)}°C
        </span>
      </td>
      <td class="py-3 px-4">
        <span class="inline-block px-2.5 py-0.5 rounded-full text-[11px] font-extrabold border ${st.details.badgeClass}">
          ${st.details.tier}
        </span>
      </td>
      <td class="py-3 px-4">
        <span class="text-xs font-semibold ${isDanger ? 'text-red-700' : 'text-slate-600'}">
          ${isDanger ? '🚫 SHIFT TO ADM MANDATED' : 'Regular In-Person'}
        </span>
      </td>
      <td class="py-3 px-4 text-right">
        <button onclick="applyPagasaStationToDashboard('${st.id}')" class="bg-deped-blue hover:bg-deped-darkblue text-white text-[11px] font-bold px-2.5 py-1.5 rounded transition shadow-sm whitespace-nowrap">
          Apply to Dashboard &rarr;
        </button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

function filterPagasaStations() {
  const query = (document.getElementById("pagasaSearchInput").value || "").toLowerCase().trim();
  const region = document.getElementById("pagasaRegionFilter").value;

  if (!appState.pagasaStationsData) return;

  let filtered = appState.pagasaStationsData.filter(st => {
    const matchesSearch = st.name.toLowerCase().includes(query) ||
                          st.province.toLowerCase().includes(query) ||
                          st.island.toLowerCase().includes(query);

    let matchesRegion = true;
    if (region === 'NCR') matchesRegion = st.island === 'NCR';
    else if (region === 'Luzon') matchesRegion = st.island === 'Luzon';
    else if (region === 'Visayas') matchesRegion = st.island === 'Visayas';
    else if (region === 'Mindanao') matchesRegion = st.island === 'Mindanao';
    else if (region === 'danger') matchesRegion = st.heatIndex >= 42;

    return matchesSearch && matchesRegion;
  });

  renderPagasaTable(filtered);
}

function applyPagasaStationToDashboard(stationId) {
  const st = PAGASA_SYNOPTIC_STATIONS.find(s => s.id === stationId);
  if (!st) return;

  const foundData = appState.pagasaStationsData ? appState.pagasaStationsData.find(s => s.id === stationId) : null;

  appState.selectedLocation = {
    name: `${st.name} (${st.province})`,
    lat: st.lat,
    lon: st.lon,
    id: st.id
  };

  if (foundData) {
    appState.airTemp = foundData.temp;
    appState.humidity = foundData.humidity;
    appState.heatIndex = foundData.heatIndex;
  }

  // Update dropdown selection
  const select = document.getElementById("quickCitySelect");
  if (select) {
    let opt = Array.from(select.options).find(o => o.value === appState.selectedLocation.name);
    if (!opt) {
      opt = document.createElement("option");
      opt.value = appState.selectedLocation.name;
      opt.textContent = "📍 " + appState.selectedLocation.name;
      select.prepend(opt);
    }
    select.value = appState.selectedLocation.name;
  }

  fetchWeatherData(st.lat, st.lon, st.name);
  renderDashboard();
  switchTab("dashboard");

  alert(`Applied PAGASA Station: ${st.name} (${st.province})\nHeat Index: ${appState.heatIndex.toFixed(1)}°C\nDashboard and School Memo updated!`);
}

function generateAdvisoryDocument() {
  const school = appState.schoolProfile;
  const hi = appState.heatIndex;
  const details = getHeatLevelDetails(hi);
  const mode = document.getElementById("advDeliveryMode") ? document.getElementById("advDeliveryMode").value : "adm_modular";
  const levels = document.getElementById("advAffectedLevels") ? document.getElementById("advAffectedLevels").value : "all";
  const effectiveDate = document.getElementById("advEffectiveDate") ? document.getElementById("advEffectiveDate").value : "Effective Immediately";

  // Update School Headers
  document.getElementById("memoDispRegion").textContent = school.region;
  document.getElementById("memoDispDivision").textContent = school.division;
  document.getElementById("memoDispSchool").textContent = school.schoolName;
  document.getElementById("memoDispSchoolDetails").textContent = `School ID: ${school.schoolId} • Monitored via DepEd Heat Protocol`;
  document.getElementById("memoDispPrincipal").textContent = school.principalName;
  document.getElementById("memoSignPrincipal").textContent = school.principalName;
  document.getElementById("memoCurrentDate").textContent = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });

  // Mode Text Mapping
  let modeTitle = "";
  let modeInstruction = "";
  if (mode === "adm_modular") {
    modeTitle = "SHIFT TO MODULAR DISTANCE LEARNING (PRINTED MODULES)";
    modeInstruction = "In-person classes are suspended. Learners will accomplish their self-learning modules (SLMs) and activity sheets at home. Teachers shall monitor learners via class group chats, SMS, and asynchronous consultation.";
  } else if (mode === "adm_online") {
    modeTitle = "TRANSITION TO ONLINE DISTANCE LEARNING";
    modeInstruction = "In-person classes are shifted to online distance learning platforms (Google Classroom / MS Teams). Teachers are advised to keep synchronous sessions brief and prioritize asynchronous tasks.";
  } else if (mode === "adm_blended") {
    modeTitle = "ADOPTION OF BLENDED LEARNING MODALITY";
    modeInstruction = "Morning in-person sessions will adjourn early prior to midday peak heat; afternoon instruction will transition entirely to home-based asynchronous distance learning.";
  } else if (mode === "suspension_total") {
    modeTitle = "FULL SUSPENSION OF CLASSES AND SCHOOL GATHERINGS";
    modeInstruction = "All classes, extracurricular rehearsals, sports training, and school operations are suspended due to hazardous heat index levels exceeding safety thresholds.";
  } else {
    modeTitle = "ENFORCEMENT OF HEAT INDEX PRECAUTIONARY PROTOCOLS";
    modeInstruction = "Regular in-person classes will proceed under strict preventive measures: mandatory 30-minute hydration pauses, suspended outdoor PE activities, and relaxed uniform attire.";
  }

  // Levels Text Mapping
  let levelsText = "all learners across Kindergarten, Elementary, Junior High School, and Senior High School";
  if (levels === "elementary") levelsText = "learners from Kindergarten to Grade 6 (Elementary Level)";
  if (levels === "jhs_shs") levelsText = "learners in Junior and Senior High School (Grades 7 to 12)";
  if (levels === "afternoon") levelsText = "learners enrolled in the Afternoon Shift schedule";

  document.getElementById("memoSubjectTitle").textContent = `SCHOOL ADVISORY: ${modeTitle} DUE TO HEAT INDEX OF ${hi.toFixed(1)}°C`;

  const memoContent = document.getElementById("memoDynamicContent");
  memoContent.innerHTML = `
    <p>
      1. In reference to <strong>DepEd Order No. 037, s. 2022</strong> (<em>"Guidelines on the Cancellation or Suspension of Classes and Work in Schools in the Event of Natural Disasters, Power Outages/Power Interruptions, and Other Calamities"</em>) and recent Department Advisories empowering School Heads to prioritize the health, safety, and well-being of learners and personnel, this Office hereby issues this advisory.
    </p>

    <div class="p-3 bg-red-50 border-l-4 border-red-600 my-2">
      <strong>OFFICIAL WEATHER OBSERVATION:</strong><br>
      As of <strong>${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</strong> today, the localized Heat Index on campus has reached 
      <span class="text-red-700 font-extrabold text-base">${hi.toFixed(1)}°C</span>, falling under the 
      <span class="font-extrabold text-red-800 uppercase">${details.tier} (${details.tagalog})</span> classification of DOST-PAGASA.
    </div>

    <p>
      2. <strong>DIRECTIVE ON LEARNING DELIVERY:</strong><br>
      To prevent acute heat exhaustion and heat stroke among students and personnel, the School Head announces the <strong>${modeTitle}</strong> for <strong>${levelsText}</strong>, <strong>${effectiveDate}</strong>.
    </p>

    <p>
      3. <strong>GUIDELINES FOR IMPLEMENTATION:</strong>
    </p>
    <ul class="list-disc list-inside space-y-1.5 pl-2">
      <li><strong>Learning Continuity:</strong> ${modeInstruction}</li>
      <li><strong>Outdoor Activities:</strong> All flag ceremonies, physical education (PE) classes, and outdoor sports practices remain cancelled until further advisory.</li>
      <li><strong>Uniform Relief:</strong> In case of necessary campus visits (e.g., retrieval of modules), students and teachers are fully authorized to wear comfortable, light-colored clothes or PE shirts.</li>
      <li><strong>Health & Hydration:</strong> Parents and guardians are earnestly requested to supervise children's hydration and limit direct exposure to midday sunlight (10:00 AM – 3:00 PM).</li>
    </ul>

    <p>
      4. Teachers and advisers shall maintain active communication with parents and learners through official Section/PTA group chats for learning task distribution and wellness updates.
    </p>

    <p>
      5. For information, wide dissemination, and strict compliance of all concerned.
    </p>
  `;
}

function copyAdvisoryText() {
  const school = appState.schoolProfile;
  const hi = appState.heatIndex;
  const details = getHeatLevelDetails(hi);
  const mode = document.getElementById("advDeliveryMode").value;
  const dateStr = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });

  let summary = `📢 [DEPED SCHOOL ADVISORY - HEAT INDEX ALERT]\n`;
  summary += `🏫 ${school.schoolName} (${school.division})\n`;
  summary += `📅 Date: ${dateStr}\n\n`;
  summary += `⚠️ Current Heat Index: ${hi.toFixed(1)}°C [${details.tier} / ${details.tagalog.toUpperCase()}]\n\n`;
  summary += `Pursuant to DepEd Order No. 037, s. 2022, in-person classes will shift to ALTERNATIVE DELIVERY MODES (ADM) / Modular Distance Learning effective immediately to safeguard learners and teachers from extreme heat.\n\n`;
  summary += `📌 Reminders:\n`;
  summary += `• Accomplish learning modules/tasks at home.\n`;
  summary += `• Outdoor school activities are suspended.\n`;
  summary += `• Drink plenty of water and avoid direct midday sun.\n\n`;
  summary += `Signed:\n${school.principalName}\nSchool Head / Principal`;

  navigator.clipboard.writeText(summary).then(() => {
    alert("Official Advisory text copied to clipboard! You can now paste this directly into your School Facebook page, Messenger group chat, or SMS broadcast.");
  }).catch(err => {
    prompt("Copy the advisory text below:", summary);
  });
}

function printOfficialAdvisory() {
  window.print();
}

// Tab Switching
function switchTab(tabId) {
  const tabs = ['dashboard', 'pagasatable', 'calculator', 'rooms', 'advisory', 'firstaid'];
  tabs.forEach(t => {
    const view = document.getElementById(`view-${t}`);
    const btn = document.getElementById(`tab-${t}`);
    if (view && btn) {
      if (t === tabId) {
        view.classList.remove('hidden');
        btn.className = "tab-btn active-tab px-3.5 py-1.5 rounded-md font-medium text-white bg-blue-700/80 transition flex items-center gap-1.5 whitespace-nowrap";
      } else {
        view.classList.add('hidden');
        btn.className = "tab-btn px-3.5 py-1.5 rounded-md font-medium text-blue-100 hover:text-white hover:bg-blue-800 transition flex items-center gap-1.5 whitespace-nowrap";
      }
    }
  });

  if (tabId === 'dashboard') {
    renderHourlyChart();
  } else if (tabId === 'pagasatable') {
    if (!appState.pagasaStationsData || appState.pagasaStationsData.length === 0) {
      fetchAllPagasaStations();
    } else {
      renderPagasaTable(appState.pagasaStationsData);
    }
  } else if (tabId === 'rooms') {
    renderRoomsTable();
  } else if (tabId === 'advisory') {
    generateAdvisoryDocument();
  }
}

// School Profile Modal & Settings
function openSchoolModal() {
  const p = appState.schoolProfile;
  document.getElementById("cfgSchoolName").value = p.schoolName;
  document.getElementById("cfgSchoolId").value = p.schoolId;
  document.getElementById("cfgSchoolRegion").value = p.region;
  document.getElementById("cfgSchoolDivision").value = p.division;
  document.getElementById("cfgPrincipalName").value = p.principalName;
  document.getElementById("schoolModal").classList.remove("hidden");
}

function closeSchoolModal() {
  document.getElementById("schoolModal").classList.add("hidden");
}

function saveSchoolProfile(e) {
  e.preventDefault();
  appState.schoolProfile = {
    schoolName: document.getElementById("cfgSchoolName").value.trim(),
    schoolId: document.getElementById("cfgSchoolId").value.trim(),
    region: document.getElementById("cfgSchoolRegion").value.trim(),
    division: document.getElementById("cfgSchoolDivision").value.trim(),
    principalName: document.getElementById("cfgPrincipalName").value.trim()
  };

  saveToLocalStorage();
  syncSchoolDisplay();
  generateAdvisoryDocument();
  closeSchoolModal();
}

function syncSchoolDisplay() {
  const p = appState.schoolProfile;
  document.getElementById("dispSchoolName").textContent = p.schoolName;
  document.getElementById("dispSchoolId").textContent = "ID: " + p.schoolId;
  document.getElementById("dispSchoolDivision").textContent = `${p.division} • ${p.region}`;
  document.getElementById("dispPrincipalName").textContent = p.principalName;
}

// LocalStorage Persistence
function saveToLocalStorage() {
  try {
    localStorage.setItem("deped_hi_school", JSON.stringify(appState.schoolProfile));
    localStorage.setItem("deped_hi_rooms", JSON.stringify(appState.classrooms));
  } catch (e) {
    console.warn("LocalStorage save error:", e);
  }
}

function loadFromLocalStorage() {
  try {
    const savedSchool = localStorage.getItem("deped_hi_school");
    if (savedSchool) {
      appState.schoolProfile = JSON.parse(savedSchool);
    }
    const savedRooms = localStorage.getItem("deped_hi_rooms");
    if (savedRooms) {
      appState.classrooms = JSON.parse(savedRooms);
    }
  } catch (e) {
    console.warn("LocalStorage load error:", e);
  }
}

// Live Clock for Philippine Standard Time
function updateLiveClock() {
  const now = new Date();
  const timeStr = now.toLocaleTimeString('en-US', { hour12: true });
  const dateStr = now.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' });
  
  const clockEl = document.getElementById("liveClock");
  const dateEl = document.getElementById("liveDate");
  if (clockEl) clockEl.textContent = timeStr;
  if (dateEl) dateEl.textContent = dateStr + " • PST";
}

// Application Initialization
window.addEventListener("DOMContentLoaded", () => {
  // Populate Cities Dropdown
  const select = document.getElementById("quickCitySelect");
  if (select) {
    select.innerHTML = "";
    PH_LOCATIONS.forEach(loc => {
      const opt = document.createElement("option");
      opt.value = loc.name;
      opt.textContent = "📍 " + loc.name;
      select.appendChild(opt);
    });
  }

  // Load persistence
  loadFromLocalStorage();
  syncSchoolDisplay();
  renderRoomsTable();

  // Clock tick
  updateLiveClock();
  setInterval(updateLiveClock, 1000);

  // Initialize Calculator default state
  onManualCalculatorChange();

  // Initial Weather Fetch for Manila
  fetchWeatherData(appState.selectedLocation.lat, appState.selectedLocation.lon, appState.selectedLocation.name);
});
